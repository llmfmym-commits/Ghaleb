# Web App APK Template

This is a source template for an Android WebView APK generator.

The template is intended to be copied by a generator, customized (name, icon, URL/HTML and settings), then built and signed.

The ZIP is NOT itself an APK.

Do not put a private release signing key in this repository or inside the consumer app.
